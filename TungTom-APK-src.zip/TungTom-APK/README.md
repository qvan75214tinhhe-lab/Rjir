# TungTom APK 1.12.0

Ứng dụng Android dùng WebView để mở PokéSurvivor và chạy userscript TungTom trên các tên miền game được cấu hình. Toàn bộ `tungtom.user.js` được giữ nguyên trong bản cập nhật này.

## Thay đổi 1.12.0

- Thêm nút bật/tắt tổng ở phía trên WebView.
- Trạng thái bật/tắt được lưu bằng SharedPreferences và giữ nguyên sau khi đóng/mở ứng dụng.
- Khi tắt, ứng dụng gỡ đăng ký script document-start và tải lại trang; không chạy userscript.
- Khi bật, đăng ký lại script trước khi tải trang tiếp theo.
- Giữ cơ chế fallback `onPageStarted` cho WebView không hỗ trợ `DOCUMENT_START_SCRIPT`.
- Giới hạn đăng ký script ở các origin HTTPS đã khai báo.
- Không thay đổi các tính năng trong userscript và không sửa cơ chế bảo vệ/phát hiện của website.

## Build APK

Yêu cầu JDK 17, Android SDK Platform 34 và Gradle 8.2.1.

```bash
gradle --no-daemon assembleDebug
```

APK đầu ra:

`app/build/outputs/apk/debug/app-debug.apk`

Có thể build trên GitHub bằng cách đưa toàn bộ thư mục dự án lên repository, sau đó vào **Actions → Build TungTom APK → Run workflow**. Tệp APK sẽ nằm trong artifact `TungTom-1.12.0-debug`.

## Kiểm thử

- Mở ứng dụng: nút hiển thị `TungTom: ĐANG BẬT` theo mặc định.
- Chạm nút: trạng thái đổi sang `ĐANG TẮT`, trang được tải lại và userscript không được đăng ký.
- Chạm lại: userscript được đăng ký lại và trang được tải lại.
- Việc website có chấp nhận tiện ích hay không vẫn do website quyết định; bản này không che giấu hoặc vô hiệu hóa cơ chế phát hiện của website.
