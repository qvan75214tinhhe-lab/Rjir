package com.tungtom.pokesurvivor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

/** WebView shell for the TungTom userscript, with a persistent master on/off switch. */
public class MainActivity extends Activity {
    private static final String HOME = "https://pokesurvivor.com/";
    private static final String PREFS = "tungtom_settings";
    private static final String PREF_ENABLED = "enabled";
    private static final String[] GAME_HOSTS = {
            "pokesurvivor.com", "www.pokesurvivor.com", "pokesurvivor.doofcraft.com"
    };

    private WebView web;
    private Button toggleButton;
    private String script = "";
    private boolean enabled = true;
    private boolean injectAtDocumentStart = false;
    private ScriptHandler scriptHandler;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        enabled = prefs.getBoolean(PREF_ENABLED, true);
        script = readAsset("tungtom.user.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        toggleButton = new Button(this);
        toggleButton.setAllCaps(false);
        toggleButton.setTextSize(14f);
        toggleButton.setGravity(Gravity.CENTER);
        toggleButton.setOnClickListener(v -> toggleTungTom());
        root.addView(toggleButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateToggleLabel();

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        registerUserscript();

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                // Compatibility fallback for WebView versions without document-start support.
                if (!injectAtDocumentStart && enabled && isGame(url) && !script.isEmpty()) {
                    view.evaluateJavascript(script, null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    // No installed handler for this external URI scheme.
                }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                recreate();
                return true;
            }
        });

        if (savedInstanceState != null && web.restoreState(savedInstanceState) != null) return;
        web.loadUrl(HOME);
    }

    private void toggleTungTom() {
        enabled = !enabled;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_ENABLED, enabled).apply();
        updateToggleLabel();
        registerUserscript();
        // A reload is required so document-start registration takes effect consistently.
        if (web != null) web.reload();
    }

    private void updateToggleLabel() {
        if (toggleButton == null) return;
        toggleButton.setText(enabled ? "TungTom: ĐANG BẬT  ·  chạm để tắt" : "TungTom: ĐANG TẮT  ·  chạm để bật");
        toggleButton.setTextColor(Color.WHITE);
        toggleButton.setBackgroundColor(enabled ? Color.rgb(25, 115, 75) : Color.rgb(75, 75, 75));
        toggleButton.setContentDescription(enabled ? "Tắt tiện ích TungTom" : "Bật tiện ích TungTom");
    }

    private void registerUserscript() {
        if (scriptHandler != null) {
            try { scriptHandler.remove(); } catch (RuntimeException ignored) { }
            scriptHandler = null;
        }
        injectAtDocumentStart = false;
        if (!enabled || script.isEmpty() || web == null) return;
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;

        Set<String> origins = new HashSet<>();
        for (String host : GAME_HOSTS) origins.add("https://" + host);
        try {
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, script, origins);
            injectAtDocumentStart = true;
        } catch (RuntimeException ignored) {
            // onPageStarted fallback remains available on older or incompatible WebView builds.
            injectAtDocumentStart = false;
        }
    }

    private static boolean isGame(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String host = uri.getHost();
        if (host == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        for (String allowed : GAME_HOSTS) if (allowed.equalsIgnoreCase(host)) return true;
        return false;
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (scriptHandler != null) {
            try { scriptHandler.remove(); } catch (RuntimeException ignored) { }
            scriptHandler = null;
        }
        if (web != null) {
            web.stopLoading();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
